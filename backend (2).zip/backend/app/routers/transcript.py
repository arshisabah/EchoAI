# backend/routers/transcript.py
"""
Thin API router for transcript endpoints.
All business logic lives in backend.services.orchestrator_service.OrchestratorService.
"""

import logging
from typing import Optional, Dict, Any

from fastapi import APIRouter, WebSocket, HTTPException, status

from backend.services.orchestrator_service import get_orchestrator

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/transcript", tags=["transcript"])

orchestrator = get_orchestrator()


@router.websocket("/ws/{session_id}")
async def websocket_transcript_endpoint(websocket: WebSocket, session_id: str):
    """
    WebSocket endpoint that delegates full lifecycle to orchestrator.handle_connection.
    The orchestrator will accept the websocket and manage messages.
    """
    try:
        await orchestrator.handle_connection(websocket, session_id)
    except Exception as e:
        logger.exception(f"WebSocket endpoint error for session {session_id}: {e}")
        # We don't re-raise here because WebSocket lifecycle is managed in handle_connection.


@router.get("/session/{session_id}")
async def get_session_transcript(session_id: str):
    try:
        return await orchestrator.get_session_transcript(session_id)
    except Exception as e:
        logger.exception(f"Failed to get session transcript {session_id}: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/session/{session_id}/emotions")
async def get_session_emotions(session_id: str):
    try:
        return await orchestrator.analyze_session_emotions(session_id)
    except Exception as e:
        logger.exception(f"Failed to analyze session emotions {session_id}: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/session/{session_id}/create")
async def create_transcript_session(session_id: str, metadata: Optional[Dict[str, Any]] = None):
    try:
        return await orchestrator.create_session(session_id, metadata)
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(ve))
    except Exception as e:
        logger.exception(f"Failed to create session {session_id}: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.delete("/session/{session_id}")
async def delete_transcript_session(session_id: str):
    try:
        return await orchestrator.delete_session(session_id)
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(ve))
    except Exception as e:
        logger.exception(f"Failed to delete session {session_id}: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/sessions")
async def list_sessions():
    try:
        return await orchestrator.list_sessions()
    except Exception as e:
        logger.exception(f"Failed to list sessions: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.get("/providers/stt")
async def get_stt_providers():
    try:
        return await orchestrator.get_stt_providers()
    except Exception as e:
        logger.exception(f"Failed to get STT providers: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))


@router.post("/providers/stt/{provider_name}")
async def set_primary_stt_provider(provider_name: str):
    try:
        return await orchestrator.set_primary_stt_provider(provider_name)
    except ValueError as ve:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(ve))
    except Exception as e:
        logger.exception(f"Failed to set primary STT provider: {e}")
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))

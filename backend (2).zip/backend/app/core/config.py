# backend/app/core/config.py

"""
Central configuration for EchoAI backend.
Loads environment variables and global settings.
"""

import os
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # --- Application ---
    APP_NAME: str = "EchoAI Backend"
    APP_VERSION: str = "3.0.0"
    DEBUG: bool = True

    # --- HuggingFace Token (for model downloads) ---
    HUGGING_FACE_TOKEN: str = os.getenv("HUGGING_FACE_TOKEN", "")

    # --- Database / Storage ---
    SESSION_STORE_TYPE: str = os.getenv("SESSION_STORE_TYPE", "memory")  # memory | mongo | redis
    DATABASE_URL: str = os.getenv("DATABASE_URL", "sqlite:///./echoai.db")

    # --- Whisper / STT Configuration ---
    WHISPER_MODEL: str = os.getenv("WHISPER_MODEL", "base")

    # --- Security / CORS ---
    ALLOWED_ORIGINS: list = ["*"]

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"

# Instantiate the global settings object
settings = Settings()
